package com.miniproject.userImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.miniproject.userImpl.UserVO;

public class UserDAO {

    // �����ͺ��̽� ���� ����
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String USER = "min";
    private static final String PASSWORD = "1234";

    // �����ͺ��̽� ������ ���� �޼���
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // ����� ������ �����ͺ��̽��� �����ϴ� �޼���
    public void insertUser(UserVO user) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = getConnection();
            String sql = "INSERT INTO users (id, pass, name, nickname, phone) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getId());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getNickname());
            pstmt.setString(5, user.getPhone());

            int result = pstmt.executeUpdate();
            if(result > 0) {
                System.out.println("User inserted successfully");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if(pstmt != null) pstmt.close();
                if(conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}