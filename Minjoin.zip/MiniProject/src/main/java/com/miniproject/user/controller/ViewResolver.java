package com.miniproject.user.controller;

public class ViewResolver {

	public void setPrefix(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setSuffix(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getView(String viewName) {
		// TODO Auto-generated method stub
		return null;
	}

}
