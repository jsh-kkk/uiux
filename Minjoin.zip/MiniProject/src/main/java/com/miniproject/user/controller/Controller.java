package com.miniproject.user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Controller {
	String handlerRequest(HttpServletRequest request, HttpServletResponse response) {
		return null;
		
	}
}
