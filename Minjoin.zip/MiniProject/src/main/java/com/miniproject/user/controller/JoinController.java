package com.miniproject.user.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.miniproject.userImpl.UserDAO;
import com.miniproject.userImpl.UserVO;

public class JoinController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // �� ������ ��������
        String id = request.getParameter("id");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String nickname = request.getParameter("nickname");
        String phone = request.getParameter("phone");

        // ��ü ����
        UserVO user = new UserVO(id, password, name, nickname, phone);

        // DB�� ����� ���� ����
        UserDAO dao = new UserDAO();
        dao.insertUser(user);

        // �α��� ��������
        response.sendRedirect("login.jsp");
    }
}