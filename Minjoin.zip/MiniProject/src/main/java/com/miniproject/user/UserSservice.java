package com.miniproject.user;

public interface UserSservice {

}
