package com.miniproject.user.controller;

import java.util.Map;

public class HandlerMapping {
	private Map<String,Controller> mappings;

	public com.miniproject.user.controller.Controller getController(java.lang.String path) {
		// TODO Auto-generated method stub
		return null;
	}		
	
	
}
