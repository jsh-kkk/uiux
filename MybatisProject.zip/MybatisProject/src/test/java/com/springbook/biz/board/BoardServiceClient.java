package com.springbook.biz.board;

import java.util.List;

import com.springbook.biz.board.impl.BoardDAO;

public class BoardServiceClient {

	public static void main(String[] args) {
		BoardDAO boardDAO = new BoardDAO();
		BoardVO vo = new BoardVO();
		
		//테스트 용 
		//글 등록
		vo.setTitle("mybatis 제목2");
		vo.setWriter("홍길동");
		vo.setContent("mybatis 내용2");
		boardDAO.insertBoard(vo);
		
		//글 수정
		vo.setTitle("mybatis 제목3");
		vo.setContent("mybatis 내용3");
		vo.setSeq(12);
		boardDAO.updateBoard(vo);
		
		//글 삭제
		vo.setSeq(7);
		boardDAO.deleteBoard(vo);
		
		//글 상세 조회
		vo.setSeq(8);
		
		BoardVO getboard = (BoardVO) boardDAO.getBoard(vo);
		
		System.out.println("==> 글 상세 조회 \n" + getboard + "\n");
		
		
		//글 목록 조회
		vo.setSearchCondition("TITLE");
		vo.setSearchKeyword("");
		
		List<BoardVO> boardList = boardDAO.getBoardList(vo);
		
		System.out.println("--> 글 목록 조회");
		
		for(BoardVO board : boardList) {
			System.out.println("==> " + board.toString());
		}
		
		
	}

}
