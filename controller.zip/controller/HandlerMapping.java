package com.springbook.view.controller;

import java.util.HashMap;
import java.util.Map;

import com.springbook.view.user.DeleteBoardController;
import com.springbook.view.user.GetBoardController;
import com.springbook.view.user.GetBoardListController;
import com.springbook.view.user.InsertBoardController;
import com.springbook.view.user.LoginController;
import com.springbook.view.user.LogoutController;
import com.springbook.view.user.UpdateBoardController;

public class HandlerMapping {

	private Map<String,Controller> mappings;		//map
	
	public HandlerMapping() {
		mappings = new HashMap<>();
		mappings.put("/login.do", new LoginController());	//요청된 url 값으로 어떤 컨트롤로 가져올지 정의해놓은 것 (정보는 map으로 리턴)
		mappings.put("/getBoardList.do", new GetBoardListController());
		mappings.put("/getBoard.do", new GetBoardController());
		mappings.put("/insertBoard.do", new InsertBoardController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		mappings.put("/logout.do", new LogoutController());
	}
	
	public Controller getController(String path) {		//uri에 있는 path정보를 넘겨옴 위에 logincontroller에서 필요하면 가져감
		
		return mappings.get(path);
	}
}
