package com.springbook.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springbook.biz.user.UserVO;
import com.springbook.biz.user.impl.UserDAO;

@Controller
public class LogoutController  {

	@RequestMapping(value="/logout.do")
	public String logout(HttpSession session) {
		System.out.println("로그아웃 처리");
		
//		ModelAndView mav = new ModelAndView();
		
		session.invalidate();
		
		return "login.jsp";
		
//		mav.setViewName("redirect:login.do");
		//mav.setViewName("login.do");
		
//		return mav;
		
//		HttpSession session = request.getSession();
//		session.invalidate();
		
//		return "login";
	}

}
