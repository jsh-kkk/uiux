package com.springbook.view.user;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.board.impl.BoardDAO;

//@Controller
public class InsertBoardController {

	@RequestMapping(value="/insertBoard.do")
	public String insertBoard(BoardVO vo, BoardDAO boardDAO) {					//BoardVO vo -> 커멘드(command)객체(spring container가 관리)

		System.out.println("글 등록 처리");
		

//		BoardDAO dao = new BoardDAO();
		boardDAO.insertBoard(vo);

		//페이지 이동, 리턴 값이 void이기 때문에 return이 없음 그래서 String으로 바꿔줌
		return "redirect:getBoardList.do";
		
		
//		public void insertBoard(HttpServletRequest request) {		

		//request.setCharacterEncoding("utf-8");
//		try {
//			request.setCharacterEncoding("utf-8");
//		}catch(UnsupportedEncodingException e) {
//			e.printStackTrace();
//		}
//
//		String title = request.getParameter("title");
//		String writer = request.getParameter("writer");
//		String content = request.getParameter("content");
//		
//		BoardVO vo = new BoardVO();
//		BoardDAO dao = new BoardDAO();
//		
//		vo.setTitle(title);
//		vo.setWriter(writer);
//		vo.setContent(content);
		
//		------------------------------------------------------
		
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("redirect:getBoardList.do");
//		return mav;		

//		------------------------------------------------------
		
//		mav.setViewName("getBoardList.do");
		
//		return "getBoardList.do";
	}

}
