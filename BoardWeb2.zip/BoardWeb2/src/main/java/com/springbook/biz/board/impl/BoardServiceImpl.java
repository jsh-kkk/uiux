package com.springbook.biz.board.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.board.BoardService;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.common.Log4jAdvice;
import com.springbook.biz.common.LogAdvice;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Autowired
	//private BoardDAO boardDAO;			//생성을 해줘야 사용할 수 있음
	private BoardDAOSpring boardDAO;
	
//	private LogAdvice log;					//공통로그 생성자
//	private Log4jAdvice log;
	
	//비즈니스로직 전 log를 실행함(공통로그)
	public BoardServiceImpl() {
//		log = new LogAdvice();
//		log = new Log4jAdvice();
		
	}

	@Override
	public void insertBoard(BoardVO vo) {
//		log.printLog();
//		log.printLogging();
		
		boardDAO.insertBoard(vo);			//@Autowired를 빼면 오류가 생김 (null point때문에)
	}

	@Override
	public void updateBoard(BoardVO vo) {
//		log.printLog();
//		log.printLogging();
		boardDAO.updateBoard(vo);
	}

	@Override
	public void deleteBoard(BoardVO vo) {
//		log.printLog();
//		log.printLogging();
		boardDAO.deleteBoard(vo);
	}

	@Override
	public BoardVO getBoard(BoardVO vo) {
//		log.printLog();
//		log.printLogging();
		return boardDAO.getBoard(vo);
	}

	@Override
	public List<BoardVO> getBoardList(BoardVO vo) {
//		log.printLog();
//		log.printLogging();
		return boardDAO.getBoardList(vo);
	}

}
