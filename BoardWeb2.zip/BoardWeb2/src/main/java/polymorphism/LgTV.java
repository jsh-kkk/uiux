package polymorphism;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("tv")
public class LgTV implements TV{
	
	// 자동 의존주입 방식 : 선언된 변수의 타입으로 의존 주입함
	@Autowired
	@Qualifier("apple")
	private Speaker speaker;
	
	public LgTV() {
		System.out.println("===> LgTV 객체생성");
	}

	public void turnOn() {
		System.out.println("LgTV  --- 전원 on");
	}
	
	public void turnOff() {
		System.out.println("LgTV  --- 전원 off");
	}
	
	public void soundUp() {
		System.out.println("LgTV  --- 소리 up");
	}
	
	public void soundDown() {
		System.out.println("LgTV  --- 전원 down");
	}

	@Override
	public void powerOn() {
		System.out.println("LgTV  --- 전원 on");
		
	}

	@Override
	public void powerOff() {
		System.out.println("LgTV  --- 전원 off");
		
	}

	@Override
	public void volumeUp() {
		speaker.volumeUp();
		//System.out.println("LgTV  --- 소리 up");
	}

	@Override
	public void volumeDown() {
		speaker.volumeDown();
		//System.out.println("LgTV  --- 전원 down");
	}
}
