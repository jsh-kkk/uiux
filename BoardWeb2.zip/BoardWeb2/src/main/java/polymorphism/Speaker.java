package polymorphism;

public interface Speaker {
	
	public void volumeUp(); 
		
	public void volumeDown(); 
		
}
