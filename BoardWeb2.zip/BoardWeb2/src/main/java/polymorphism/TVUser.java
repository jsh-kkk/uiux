package polymorphism;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		
//		SamsungTV tv = new SamsungTV();
//		
//		tv.powerOn();
//		tv.powerOff();
//		tv.volumeUp();
//		tv.volumeDown();
//
//		LgTV ltv = new LgTV();
//		
//		ltv.turnOn();
//		ltv.turnOff();
//		ltv.soundUp();
//		ltv.soundDown();
		
//		TV tv = new LgTV();
//		
//		tv.powerOn();
//		tv.powerOff();
//		tv.volumeUp();
//		tv.volumeDown();
	
//		BeanFactory fact = new BeanFactory();
//		TV tv = (TV)fact.getBean("lg");
//		
//		tv.powerOn();
//		tv.powerOff();
//		tv.volumeUp();
//		tv.volumeDown();
	
//		BeanFactory fact = new BeanFactory();
	
		//org.springframework가 95퍼센트 import
		//GenericXmlApplicationContext가 스프링 컨테이너에서 관리를해주는 클래스(역할)
		//spring 컨테이너에다가 관리함 (new를 사용하지않음)
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");	
		
		TV tv = (TV)factory.getBean("tv");	//return타입 = object, 싱글톤 패턴
//		TV tv2 = (TV)factory.getBean("tv");
		
		tv.powerOn();
		tv.powerOff();
		tv.volumeUp();
		tv.volumeDown();
		
		
	
	}

}






























