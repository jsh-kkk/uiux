package polymorphism;

public class BeanFactory {
	//클래스 생성(객체 생성)하는 역할 bean == 객체
	
	public Object getBean(String beanName) {	//아래쓰는 객체를 우리가 알 수 없기 때문에 object타입을 사용
		
		if(beanName.contentEquals("samsung")) {
			return new SamsungTV();
		}else {
			return new LgTV();
		}
		
	}
	
}
